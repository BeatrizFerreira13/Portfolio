-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema cornerstoreshaving_group_project
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema cornerstoreshaving_group_project
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `cornerstoreshaving_group_project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `cornerstoreshaving_group_project` ;

-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`country`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`country` (
  `CountryID` VARCHAR(3) NOT NULL,
  `CountryName` VARCHAR(40) NOT NULL,
  `ShippingCost` DECIMAL(10,2) NOT NULL,
  `TaxRate` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`CountryID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`location`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`location` (
  `LocationID` INT NOT NULL AUTO_INCREMENT,
  `LocationName` VARCHAR(40) NOT NULL,
  `CountryID` VARCHAR(3) NOT NULL,
  PRIMARY KEY (`LocationID`),
  INDEX `fk_location_country1_idx` (`CountryID` ASC) VISIBLE,
  CONSTRAINT `fk_location_country1`
    FOREIGN KEY (`CountryID`)
    REFERENCES `cornerstoreshaving_group_project`.`country` (`CountryID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`customer` (
  `CustomerID` INT NOT NULL AUTO_INCREMENT,
  `LocationID` INT NULL DEFAULT NULL,
  `FirstName` VARCHAR(50) NOT NULL,
  `LastName` VARCHAR(50) NOT NULL,
  `DeliveryAddress` VARCHAR(40) NOT NULL,
  `FiscalNumber` INT NULL DEFAULT NULL,
  `BirthDate` DATE NOT NULL,
  `Email` VARCHAR(200) NULL DEFAULT NULL,
  `PhoneNumber` VARCHAR(13) NULL DEFAULT NULL,
  PRIMARY KEY (`CustomerID`),
  INDEX `fk_customer_location1_idx` (`LocationID` ASC) VISIBLE,
  CONSTRAINT `fk_customer_location1`
    FOREIGN KEY (`LocationID`)
    REFERENCES `cornerstoreshaving_group_project`.`location` (`LocationID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`warehouse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`warehouse` (
  `WarehouseID` INT NOT NULL AUTO_INCREMENT,
  `WarehousePhoneNumber` VARCHAR(50) NOT NULL,
  `WarehouseEmail` VARCHAR(50) NULL DEFAULT NULL,
  `LocationID` INT NOT NULL,
  PRIMARY KEY (`WarehouseID`),
  INDEX `fk_warehouse_location1_idx` (`LocationID` ASC) VISIBLE,
  CONSTRAINT `fk_warehouse_location1`
    FOREIGN KEY (`LocationID`)
    REFERENCES `cornerstoreshaving_group_project`.`location` (`LocationID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`ordering`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`ordering` (
  `OrderID` INT NOT NULL AUTO_INCREMENT,
  `CustomerID` INT NOT NULL,
  `ProductID` INT NOT NULL,
  `WarehouseID` INT NOT NULL,
  `QuantityPurchased` INT NOT NULL,
  `DatePurchased` DATE NULL DEFAULT '1900-01-01',
  PRIMARY KEY (`OrderID`),
  INDEX `fk_ordering_customer1_idx` (`CustomerID` ASC) VISIBLE,
  INDEX `fk_ordering_product1_idx` (`ProductID`ASC) VISIBLE,
  INDEX `fk_ordering_warehouse1_idx` (`WarehouseID` ASC) VISIBLE,
  CONSTRAINT `fk_ordering_customer1`
    FOREIGN KEY (`CustomerID`)
    REFERENCES `cornerstoreshaving_group_project`.`customer` (`CustomerID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE,
  CONSTRAINT `fk_ordering_product1`
	FOREIGN KEY (`ProductID`)
    REFERENCES `cornerstoreshaving_group_project`.`product`(`ProductID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE,
  CONSTRAINT `fk_ordering_warehouse1`
    FOREIGN KEY (`WarehouseID`)
    REFERENCES `cornerstoreshaving_group_project`.`warehouse` (`WarehouseID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`invoice`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`invoice` (
  `InvoiceID` INT NOT NULL AUTO_INCREMENT,
  `InvoiceDate` DATE NOT NULL,
  `OrderID` INT NOT NULL,
  `CustomerID` INT NOT NULL,
  PRIMARY KEY (`InvoiceID`),
  INDEX `fk_invoice_ordering1` (`OrderID` ASC) VISIBLE,
  INDEX `fk_invoice_customer1_idx` (`CustomerID` ASC) VISIBLE,
  CONSTRAINT `fk_invoice_customer1`
    FOREIGN KEY (`CustomerID`)
    REFERENCES `cornerstoreshaving_group_project`.`customer` (`CustomerID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE,
  CONSTRAINT `fk_invoice_ordering1`
    FOREIGN KEY (`OrderID`)
    REFERENCES `cornerstoreshaving_group_project`.`ordering` (`OrderID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`log_stock`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`log_stock` (
  `LogStockID` INT NOT NULL AUTO_INCREMENT,
  `USR` VARCHAR(30) NOT NULL,
  `TS` DATE NOT NULL,
  `ProductID` INT NOT NULL,
  `WarehouseID` INT NOT NULL,
  `OldStock` INT NOT NULL,
  `NewStock` INT NOT NULL,
  PRIMARY KEY (`LogStockID`))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`product` (
  `ProductID` INT NOT NULL AUTO_INCREMENT,
  `ProductName` VARCHAR(50) NOT NULL,
  `ProductPrice` DECIMAL(8,2) NOT NULL DEFAULT '0.00',
  `ProductType` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`ProductID`))
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`promotion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`promotion` (
  `PromotionID` INT NOT NULL AUTO_INCREMENT,
  `ProductID` INT NOT NULL,
  `PromotionalValue` DECIMAL(10,2) NULL DEFAULT 0,
  `PromotionStartDate` DATE NULL DEFAULT NULL,
  `PromotionEndDate` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`PromotionID`),
  INDEX `fk_promotion_product1_idx` (`ProductID` ASC) VISIBLE,
  CONSTRAINT `fk_promotion_product1`
    FOREIGN KEY (`ProductID`)
    REFERENCES `cornerstoreshaving_group_project`.`product` (`ProductID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`rating`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`rating` (
  `RatingID` INT NOT NULL AUTO_INCREMENT,
  `ProductID` INT NOT NULL,
  `NumericalRating` INT NULL DEFAULT NULL,
  `Comment` VARCHAR(999) NULL DEFAULT NULL,
  PRIMARY KEY (`RatingID`),
  INDEX `fk_rating_product1_idx` (`ProductID` ASC) VISIBLE,
  CONSTRAINT `fk_rating_product1`
    FOREIGN KEY (`ProductID`)
    REFERENCES `cornerstoreshaving_group_project`.`product` (`ProductID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 1
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `cornerstoreshaving_group_project`.`stock`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `cornerstoreshaving_group_project`.`stock` (
  `ProductID` INT NOT NULL,
  `WarehouseID` INT NOT NULL,
  `StockQuantity` INT NOT NULL,
  INDEX `fk_product_has_warehouse_warehouse1_idx` (`WarehouseID` ASC) VISIBLE,
  INDEX `fk_product_has_warehouse_product1_idx` (`ProductID` ASC) VISIBLE,
  CONSTRAINT `fk_product_has_warehouse_product1`
    FOREIGN KEY (`ProductID`)
    REFERENCES `cornerstoreshaving_group_project`.`product` (`ProductID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE,
  CONSTRAINT `fk_product_has_warehouse_warehouse1`
    FOREIGN KEY (`WarehouseID`)
    REFERENCES `cornerstoreshaving_group_project`.`warehouse` (`WarehouseID`)
    ON DELETE RESTRICT
	ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `cornerstoreshaving_group_project` ;

-- -----------------------------------------------------
-- View `cornerstoreshaving_group_project`.`INVOICE TOTALS`
-- -----------------------------------------------------
SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));
USE `cornerstoreshaving_group_project`;
CREATE VIEW `invoice_totals` AS
SELECT
	CONCAT(c.FirstName, ' ', c.LastName) AS "Client Name",
    i.InvoiceID AS "Invoice Number",
    i.InvoiceDate AS "Issue Date",
    c.DeliveryAddress AS "Delivery Address",
    l.LocationName AS "Location",
    "4829-908 Rua Gillete N33, Bragança" AS "Company Address",
	ROUND(SUM(o.QuantityPurchased)*(p.ProductPrice),2) AS "SubTotal",
    ROUND(SUM(o.QuantityPurchased)*(p.ProductPrice*pr.PromotionalValue),2) AS "Discount",
    ct.ShippingCost AS "Shipping Cost",
    ct.TaxRate AS "Tax Rate",
    SUM(o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*IFNULL(pr.PromotionalValue, 0)))*ct.TaxRate AS "Tax",
    SUM(o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*IFNULL(pr.PromotionalValue, 0)))*(1+ct.TaxRate) + ct.ShippingCost AS "Total"
FROM invoice i
JOIN ordering o ON i.OrderID = o.OrderID
JOIN product p ON p.ProductID=o.ProductID
JOIN customer c ON c.CustomerID = o.CustomerID
JOIN location l ON c.LocatioNID = l.LocationID
JOIN country ct ON ct.CountryID = l.CountryID
JOIN promotion pr ON o.ProductID = pr.ProductID
GROUP BY i.InvoiceID;

-- -----------------------------------------------------
-- View `cornerstoreshaving_group_project`.`INVOICE DETAILS`
-- -----------------------------------------------------
SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));
USE `cornerstoreshaving_group_project`;
CREATE VIEW `invoice_details` AS
SELECT 
	p.ProductName AS "Product Name", 
	ROUND(SUM(o.QuantityPurchased),2) AS "Total Quantity", 
    p.ProductPrice AS "Product Price",
	ROUND(SUM(o.QuantityPurchased)*(p.ProductPrice),2) AS "Amount"
FROM ordering o
JOIN invoice i ON i.OrderID = o.OrderID
JOIN product p ON p.ProductID=o.ProductID
JOIN promotion pr ON o.ProductID = pr.ProductID
GROUP BY i.InvoiceID;

DELIMITER $$
USE `cornerstoreshaving_group_project`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `cornerstoreshaving_group_project`.`AFTER INSERT ORDERING`
AFTER INSERT ON `cornerstoreshaving_group_project`.`ordering`
FOR EACH ROW
BEGIN
	UPDATE stock s
		SET s.StockQuantity = s.StockQuantity - NEW.QuantityPurchased
        WHERE NEW.ProductID = s.ProductID
        AND NEW.WarehouseID = s.WarehouseID;
	INSERT INTO invoice(InvoiceDate, OrderID, CustomerID)
    VALUES (ADDDATE(NEW.DatePurchased, INTERVAL 1 DAY), NEW.OrderID, NEW.CustomerID);
END$$

USE `cornerstoreshaving_group_project`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `cornerstoreshaving_group_project`.`Log Trigger`
AFTER UPDATE ON `cornerstoreshaving_group_project`.`stock`
FOR EACH ROW
BEGIN
	INSERT INTO log_stock(USR, TS, ProductID, WarehouseID, OldStock, NewStock) 
    VALUES (USER(), NOW(), NEW.ProductID, NEW.WarehouseID, OLD.StockQuantity, NEW.StockQuantity);
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

INSERT INTO `country`(`CountryID`, `CountryName`, `ShippingCost`, `TaxRate`)
VALUES
('POR', 'Portugal', 2.50, 0.13),
('ITL', 'Italy', 5.00, 0.10),
('GER', 'Germany', 5.00, 0.09);

INSERT INTO `location`(`LocationName`, `CountryID`)
VALUES
('Lisbon', 'POR'),
('Porto', 'POR'),
('Leiria', 'POR'),
('Açores', 'POR'),
('Rome', 'ITL'),
('Milan', 'ITL'),
('Frankfurt', 'GER'),
('Berlin', 'GER'),
('Munich', 'GER');

INSERT INTO `Warehouse`(`WarehouseID`, `LocationID`,`WarehousePhoneNumber`, `WarehouseEmail`)
VALUES
(1, 1, 351213333500,'Lisbon1@gmail.com'),
(2, 2, 351223455670, 'porto1@gmail.com'),
(3, 3, 351244234567, 'leiria@gmail.com'),
(4, 4, 351292334569, 'Açores@gmail.com'),
(5, 5, 393492223334, 'rome@gmail.com'),
(6, 6, 394333333444, 'milan@gmail.com'),
(7, 7, 492233441234, 'Frankfurt@gmail.com'),
(8, 8, 491265794321, 'Berlin@gmail.com'),
(9, 9, 491245567543, 'munich@gmail.com');

INSERT INTO `product` (`ProductName`,`ProductPrice`,`ProductType`) 
VALUES
('RazorBlades', 2.99, 'Blades and Handles'),
('Shaving Foam', 4.95, 'Hygiene and Beauty'), 
('Starter Kit', 21.00, 'Kits'),
('AfterShave', 12.99, 'Hygiene and Beauty'),
('Deluxe Kit', 50.00, 'Kits'),
('RazorHandle', 18.00, 'Blades and Handles');

INSERT INTO `customer`(`LocationID`, `FirstName`, `LastName`, `DeliveryAddress`, `FiscalNumber`, `BirthDate`, `Email`, `PhoneNumber`)
VALUES
(1, 'Bianca', 'Taffee', '23 Garrison Parkway', 688181331, '1955-02-15', 'btaffeef@tamu.edu', 351911964786),
(1, 'Tripp', 'Guyan', '945 Drewry Trail', 909822887, '1974-08-19', 'tguyani@go.com', 351936731086),
(2, 'Chelsey', 'Dominy', '7 Kinsman Place', 418651377, '1966-11-20', 'cdominyr@ow.ly', 351966419855),
(3, 'Zilvia', 'Whiteman', '99 Fieldstone Circle', 418457332, '1956-02-18', 'zwhiteman3@elegantthemes.com', 351969763756),
(4, 'Sheri', 'Dumphy', '661 Hudson Terrace', 623443608, '1959-07-03', 'sdumphy2@whitehouse.gov', 351923399120),
(4, 'Tailor', 'Renshell', '7248 Summer Ridge Avenue', 850821652, '2002-03-16', 'trenshellt@google.cn', 351934759748),
(5, 'Iorgos', 'DAlessio', '20002 Washington Point', 697923012, '1946-09-19', 'idales-siom@odnoklassniki.ru', 351921874080),
(6, 'Ernie', 'McClounan', '19694 Stoughton Lane', 843354130, '1967-03-30', 'emcclounan1@e-recht24.de', 491484585924),
(6, 'Maribeth', 'Cawley', '2 Summerview Center', 851974515, '1998-08-11', 'mcawleys@unesco.org', 491662578538),
(9, 'Leisha', 'Memory', '3 Ohio Hill', 390386671, '1999-06-04', 'lmemmoryd@bbc.co.uk', 393276307892),
(7, 'Pearce', 'MacParland', '4 Sherman Trail', 653089021, '1975-04-03', 'pmacparlande@ow.ly', 393107626618),
(8, 'Shanta', 'Ferron', '95 Jay Drive', 728969086, '1977-01-28', 'sferronb@oakley.com', 393072518473);

INSERT INTO `rating`(`ProductID`, `NumericalRating`, `Comment`)
VALUES
(1, 5, 'Great deal. Blades are very sharp. I highly recommend these!'),
(2, 5, 'Smells so so so so so so good!!!!'),
(2, 5, 'I am in love with how this shaving foam smells.'),
(4, 3, 'Rusted after a month. What a rip off.'),
(1, 5, 'They work.'),
(4, 1, 'Terrible service, food was barely edible. Would give 0 stars if I could.'),
(4, 5, 'Nice and heavy.'),
(1, 4, 'Cant tell the difference between these and the ones you buy at pingo doce. Good if youre al-ready ordering from here.'),
(1, 5, 'Awesome blades. I use them for home repairs too.'),
(2, 4, 'Soap works just as well. I agree with the other reviewers though, it smells great.'),
(1, 2, 'I ordered a doll for my niece and received these straws instead. The straws were fine, but this ruined my nieces birthday surprise.'),
(1, 1, 'Not very good.'),
(3, 4, 'Stings.'),
(5, 5, 'Got a little of everything at a discount. I like it all so far.'),
(4, 1, 'This company is terrible.'),
(3, 5, 'Got this as a gift for my husband. He seemed to like it.'),
(3, 4, ''),
(3, 4, ''),
(6, 4, ''),
(2, 5, ''),
(6, 5, ''),
(2, 5, ''),
(1, 5, ''),
(5, 4, ''),
(1, 5, ''),
(6, 5, ''),
(3, 5, ''),
(5, 4, ''),
(4, 5, ''),
(1, 4, '');

INSERT INTO `promotion`(`ProductID`,`PromotionalValue`,`PromotionStartDate`,`PromotionEndDate`)
VALUES
(1, .00, NULL, NULL),
(2, .80, '2019-01-01', '2022-12-31'),
(3, .00, NULL, NULL),
(4, .36, '2020-01-01', '2022-02-04'),
(5, .00, NULL, NULL),
(6, .12, '2020-01-01', '2022-05-01');


INSERT INTO `stock`(`ProductID`, `WarehouseID`, `StockQuantity`)
VALUES
(1, 1, 50000),
(2, 1, 20000),
(3, 1, 15000),
(2, 2, 22000),
(3, 2, 13000),
(3, 3, 12000),
(3, 4, 16000),
(3, 5, 17000),
(3, 6, 15000),
(4, 6, 25000),
(3, 7, 14000),
(5, 7, 15000),
(3, 8, 16000),
(3, 9, 13500),
(6, 9, 20000);


INSERT INTO `ordering`(`CustomerID`, `ProductID`, `WarehouseID` , `QuantityPurchased`, `DatePurchased`) 
VALUES
(8, 3,  1, 4, '2021-08-27'),
(8, 2,  1, 3, '2020-12-07'),
(4, 2,  2, 2, '2020-10-28'),
(1, 6,  9, 5, '2020-07-19'),
(9, 2,  2, 3, '2021-01-30'),
(3, 2,  1, 5, '2020-05-17'),
(10, 5,  7, 1, '2021-03-04'),
(5, 5,  7, 3, '2021-10-28'),
(9, 3,  3, 1, '2021-05-17'),
(2, 3,  4, 2, '2020-06-24'),
(3, 3,  1, 2, '2020-09-24'),
(5, 6,  9, 2, '2021-09-03'),
(8, 5,  7, 4, '2020-02-19'),
(7, 6,  9, 3, '2021-06-04'),
(12, 3, 5, 3, '2021-06-18'),
(4, 4,  6, 1, '2020-07-13'),
(9, 4,  6, 4, '2020-02-18'),
(3, 6,  9, 2, '2020-03-19'),
(12, 2, 2, 2, '2020-10-06'),
(5, 4,  6, 2, '2020-02-18'),
(1, 3,  1, 2, '2021-06-27'),
(1, 5,  7, 2, '2021-01-17'),
(11, 4, 6, 5, '2021-08-31'),
(9, 5,  7, 4, '2020-11-25'),
(8, 3,  2, 3, '2020-06-26'),
(11, 2, 1, 5, '2021-06-26'),
(3, 6,  9, 5, '2020-05-16'),
(10, 4,  6, 4, '2020-08-03'),
(2, 1,  1, 1, '2021-09-14'),
(6, 3,  8,1, '2021-06-27');
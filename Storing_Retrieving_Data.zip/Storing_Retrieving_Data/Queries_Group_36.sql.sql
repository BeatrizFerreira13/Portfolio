-- Step F --
 
-- 1--
SELECT CONCAT(c.`FirstName`, ' ', c.`LastName`) as `Customer Name`, o.`DatePurchased` AS `Date of Purchase`, p.`ProductName` AS `Product Name`
FROM customer AS c, ordering o, product p, invoice i
WHERE c.CustomerID = o.CustomerID 
AND o.OrderID = i.OrderID 
AND o.ProductID = p.ProductID
AND o.`DatePurchased` 
BETWEEN '2020-12-07' AND '2021-08-27';
-- The execution time at both the client side and the server side is less than 0.1 seconds
-- making it feel instantaneous
-- The execution plan shows the rows scanned to complete the query. In this case, the customer table
-- does not have an index, so it was less efficient. If we wanted to optimize the database to run 
-- the query we could add an index
 
-- 2--
# Criteria to define the best customers: the ones that have spent the most money on the company's products
SELECT CONCAT(c.`FirstName`, ' ', c.`LastName`) AS `Customer Name`, 
ROUND(SUM((o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*pr.PromotionalValue))),2) AS `Money Spent`
FROM customer c, ordering o, product p, invoice i, promotion pr
WHERE c.CustomerID = o.CustomerID 
AND o.OrderID = i.OrderID 
AND o.ProductID = p.ProductID 
GROUP BY `Customer Name`
ORDER BY `Money Spent` DESC
LIMIT 3;
-- The execution time at both the client side and the server side is less than 0.1 seconds
-- making it feel instantaneous
-- The execution plan shows the rows scanned to complete the query. In this case, the customer
-- and promotion tables don´t have an index, so it was less efficient. If we wanted to optimize  
-- the database to run the query we could add an index

-- 3--
SELECT CONCAT(MIN(o.`DatePurchased`), ' - ', MAX(o.`DatePurchased`)) AS SalesPeriod, 
ROUND(SUM((o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*pr.PromotionalValue))),2) AS TotalNumberSales,
# the function datediff will return the difference between two date values in years and months 
ROUND(SUM((o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*pr.PromotionalValue)))/(DATEDIFF(MAX(o.`DatePurchased`), MIN(o.`DatePurchased`))/365), 2) AS AverageYear,
ROUND(SUM((o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*pr.PromotionalValue)))/(DATEDIFF(MAX(o.`DatePurchased`), MIN(o.`DatePurchased`))/30), 2) AS AverageMonth
FROM customer c, ordering o, product p, invoice i, promotion pr
WHERE c.CustomerID = o.CustomerID 
AND o.OrderID = i.OrderID 
AND o.ProductID = p.ProductID;
-- The execution time at both the client side and the server side is less than 0.1 seconds
-- making it feel instantaneous
-- The execution plan shows the rows scanned to complete the query. In this case, the promotion
-- and produdt and ordering tables don´t have a possible index, so it was less efficient. If we wanted to optimize  
-- the database to run the query we could add an index.

-- 4 --
SELECT 
	ct.CountryName AS "Country", 
    l.LocationName AS "Location",
    ROUND(SUM((o.QuantityPurchased)*(p.ProductPrice-(p.ProductPrice*pr.PromotionalValue))),2) AS "Sales"
FROM ordering o
JOIN product p ON p.ProductID=o.ProductID
JOIN promotion pr ON p.ProductID = pr.ProductID
JOIN customer c ON c.CustomerID=o.CustomerID
JOIN location l ON c.LocationID=l.LocationID
JOIN country ct ON l.CountryID=ct.CountryID
GROUP BY ct.CountryID, l.LocationID;
-- The execution time at both the client side and the server side is less than 0.1 seconds
-- making it feel instantaneous
-- The execution plan shows the rows scanned to complete the query. In this case, the country table 
-- doesn´t have a possible index, so it was less efficient. If we wanted to optimize  
-- the database to run the query we could add an index.

-- 5 --
SELECT l.LocationName AS "Location", p.ProductName AS "Product Name", ROUND(AVG(r.NumericalRating),2) AS "Rating"
FROM ordering o
JOIN customer c ON c.CustomerID = o.CustomerID
JOIN location l ON l.LocationID = c.LocationID
JOIN product p ON o.ProductID=p.ProductID
JOIN rating r ON r.ProductID = p.ProductID
GROUP BY l.LocationID, p.ProductID;
-- The execution time at both the client side and the server side is less than 0.1 seconds
-- making it feel instantaneous
-- The execution plan shows the rows scanned to complete the query. In this case, the location table 
-- doesn´t have a possible index, so it was less efficient. If we wanted to optimize  
-- the database to run the query we could add an index.